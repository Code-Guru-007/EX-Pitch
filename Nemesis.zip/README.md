<h1 align="center">
Bookmark landing page

<h3 align="center">
ReactJS Responsivo + Styled Components e Rotas.

### Projeto Design GERAL ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/desktop-preview.jpg)

### Projeto Design HOME ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/home.png)

### Projeto Design CARDS ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/cards.png)

### Projeto Design FEATURES ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/features.png)


### Projeto Design PERGUNTAS ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/perguntas.png)

### Projeto Design CONTATO E-MAIL ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/contato.png)


### Projeto Design ENVIO DO E-MAIL COM SUCESSO ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/emailSucesso.png)

### Projeto Design CRIAR CONTA ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/criarConta.png)

### Projeto Design LOGIN CONTA ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/login.png)


### Projeto Design MENU MOBILE ⬇️

![image](https://raw.githubusercontent.com/techjuliana/Bookmark-landing-page/main/design/menuMobile.png)

### `npm start`

## Tech Juliana

<a href="https://www.linkedin.com/in/techjuliana">
 <sub><b>Juliana Bitencourt</b></sub></a>  <a href="https://www.linkedin.com/in/techjuliana" title="LinkedIn">🚀</a>

Elaborado por Juliana Bitencourt
<br> Entre em contato!👋🏽 </br>

 <div> 
  <a href="https://www.linkedin.com/in/techjuliana" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" target="_blank"></a> 
</div>
